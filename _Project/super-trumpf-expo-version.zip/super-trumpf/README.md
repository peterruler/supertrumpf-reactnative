# Sample Snack app

Open the `App.js` file to start writing some code. You can preview the changes directly on your phone or tablet by scanning the **QR code** or use the iOS or Android emulators. When you're done, click **Save** and share the link!

When you're ready to see everything that Expo provides (or if you want to use your own editor) you can **Download** your project and use it with [expo-cli](https://docs.expo.io/get-started/installation).

All projects created in Snack are publicly available, so you can easily share the link to this project via link, or embed it on a web page with the `<>` button.

If you're having problems, you can tweet to us [@expo](https://twitter.com/expo) or ask in our [forums](https://forums.expo.io/c/snack).

Snack is Open Source. You can find the code on the [GitHub repo](https://github.com/expo/snack).


---------------------------------
# installation

install expo `yarn global add expo-cli`

(scaffold new app: `expo init SumpertrumpfReactNative -t expo-template-blank-typescript`)

install dependencies via cmd-line, run: `yarn`

# run via expo webapp

 scan qr code with phone

# emulator ios and/or android

with android sdk and emulator, run (need android version e.g. 11, Emulator for e. g. pixel 2):

 
 `expo start --android`


 `expo start --web`

# routing

use this navigation solution instead of react-router:

https://reactnavigation.org/docs/navigating

# dependencies

see package.json
 
 
# demo snack on expo

https://snack.expo.dev/@petethegreat/super-trumpf

