import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  headline: {
    fontSize: 20,
    fontWeight: 'bold',
  }
});

export default styles;
